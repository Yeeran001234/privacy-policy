
const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

// ใช้ body-parser เพื่ออ่าน JSON
app.use(bodyParser.json());

// Route สำหรับทดสอบ Webhook
app.post('/webhook', (req, res) => {
    console.log('Webhook event received:', req.body);
    res.status(200).send('OK');
});

app.get('/', (req, res) => {
    res.send('LINE Webhook is working!');
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
